# web-worker-example
A simple example of using HTML5 web workers with Node.

The photos in the images folder were downloaded from [pixabay.com] and are in the public domain.
